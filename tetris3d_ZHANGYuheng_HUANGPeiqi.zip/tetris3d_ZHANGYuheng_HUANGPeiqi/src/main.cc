#include "app.h"

int main() {
    Tetris3DApp app;
    app.Run();
}